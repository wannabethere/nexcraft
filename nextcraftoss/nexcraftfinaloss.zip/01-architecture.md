# 01 — Architecture

## High-level

`nexcraft` deploys as a driver / worker system. The driver is the control plane: client-facing API, cache, routing, multi-tenant policy. Workers are the data plane: connection pools, executors, source-side query execution. Redis is the shared coordination state.

```
┌───────────────────────────────────────────────────────────────────┐
│                Caller (agent, app, BI tool, notebook)             │
│           Already has dialect-correct SQL + source_id             │
└───────────────────────────┬───────────────────────────────────────┘
                            │  Flight SQL  /  HTTP
                            ▼
┌───────────────────────────────────────────────────────────────────┐
│                            Driver(s)                              │
│   Auth → Tenant resolution → Catalog → Cache check → Admission    │
│            → Worker selection → Dispatch → Stream proxy           │
└─────┬─────────────────────────────┬───────────────────────────────┘
      │                             │
      ▼                             ▼
  ┌──────┐                    ┌─────────────┐
  │Redis │                    │  Workers    │  (stateless, tier-based)
  │      │                    │             │
  │cache │                    │ FedSQLClient│
  │regis-│                    │ Router      │
  │try   │                    │ Executors   │
  │quotas│                    │ Conn pools  │
  └──────┘                    └──────┬──────┘
                                     │
                                     ▼
                        ┌─────────────────────────┐
                        │  Source executors       │
                        │ ┌──────────┬──────────┐ │
                        │ │ Pass-    │ DataFusion│ │
                        │ │ through  │ -native   │ │
                        │ │  PG/SF/  │  Iceberg/ │ │
                        │ │  BQ      │  Delta    │ │
                        │ └──────────┴──────────┘ │
                        └────────────┬────────────┘
                                     │
                                     ▼
                                  Sources
```

The driver coordinates. Workers execute. Redis is the only shared state.

Detailed driver and worker design: see [`10-driver-worker.md`](10-driver-worker.md).

## Two execution paths inside each worker

Within a worker, sources fall into two categories with genuinely different semantics. The protocol unifies them; the implementations don't pretend to be the same shape.

### Pass-through executors
Postgres, Snowflake, BigQuery, MySQL, MSSQL — sources that *are* SQL engines. The executor sends the dialect SQL to the source, the source plans and runs it, the executor wraps the result cursor as an Arrow stream. DataFusion is not in the picture.

### DataFusion-native executors
Iceberg, Delta, raw Parquet on object storage — formats, not engines. The executor uses `datafusion-python` as the engine, registers the format-specific `TableProvider`, and lets DataFusion plan and execute the query with predicate/projection pushdown into the scan layer.

Both implementations satisfy the same `SourceExecutor` protocol and return the same `AsyncIterator[pa.RecordBatch]`. Callers don't need to know or care which path is in use.

```
                  ┌──────────────────────────────────┐
                  │           Worker                 │
                  │  (one of N in a tier pool)       │
                  └────────────────┬─────────────────┘
                                   │
                                   ▼
                         WorkerRouter (in-process)
                                   │
                  ┌────────────────┴─────────────────┐
                  │                                  │
                  ▼                                  ▼
       ┌──────────────────┐               ┌──────────────────┐
       │ Pass-through     │               │ DataFusion-      │
       │ path             │               │ native path      │
       │                  │               │                  │
       │ PostgresExecutor │               │ IcebergExecutor  │
       │ SnowflakeExecutor│               │ DeltaExecutor    │
       │ BigQueryExecutor │               │                  │
       │                  │               │ datafusion-python│
       │ ADBC drivers     │               │ + TableProvider  │
       │                  │               │ + pushdown       │
       └────────┬─────────┘               └─────────┬────────┘
                │                                   │
                └───────────────┬───────────────────┘
                                ▼
                  CancellableArrowStream
                    (bounded queue, deadline,
                     cancel, budget enforcement)
                                │
                                ▼
              AsyncIterator[pa.RecordBatch]
                                │
                                ▼
                    back to driver, then client
```

The two paths are deliberately separate. They share the protocol, the streaming primitive, the per-worker router, and nothing else.

## Layer model

The system is layered. Each layer depends only on layers below.

```
┌─────────────────────────────────────────────────────────────────┐
│ 8 │ Driver service     Auth • Routing • Cache • Admission       │
├─────────────────────────────────────────────────────────────────┤
│ 7 │ Public servers     Flight SQL • HTTP/REST  (driver-side)    │
├─────────────────────────────────────────────────────────────────┤
│ 6 │ Worker service     Internal Flight • Capacity reporting     │
├─────────────────────────────────────────────────────────────────┤
│ 5 │ Public API         FedSQLClient • Router    (worker-side)   │
├─────────────────────────────────────────────────────────────────┤
│ 4 │ Source executors   Postgres • Snowflake • BQ • Iceberg…     │
├─────────────────────────────────────────────────────────────────┤
│ 3 │ Streaming          CancellableArrowStream • budgets         │
├─────────────────────────────────────────────────────────────────┤
│ 2 │ Pluggables         Catalog • ConnectionProvider             │
├─────────────────────────────────────────────────────────────────┤
│ 1 │ Core protocols     SourceExecutor • QueryContext • errors   │
└─────────────────────────────────────────────────────────────────┘
```

Layer 1 has zero non-stdlib dependencies — it's the integration surface and stays tiny. Layers 4-5 are the worker-internal stack. Layer 6 is the worker's external surface (driver-facing). Layers 7-8 are the driver.

## Component responsibilities

### Layer 1 — Core protocols (`nexcraft.core`)
Defines `SourceExecutor`, `Catalog`, `ConnectionProvider`, `QueryContext`, `SourceDescriptor`, `ConnectionHandle`, and the typed error hierarchy. Pure protocols and dataclasses. No I/O. The only fully stable surface in v0.1.

### Layer 2 — Pluggables (`nexcraft.catalog`, `nexcraft.connection`)
Reference implementations of the catalog and connection-provider protocols. Production users plug their own in.

- `InMemoryCatalog`, `YAMLCatalog` for development and tests.
- `EnvVarConnectionProvider`, `StaticConnectionProvider` for development.
- The protocols are the API; the impls are *examples*.

### Layer 3 — Streaming (`nexcraft.streaming`)
The `CancellableArrowStream` primitive. Wraps a producer (driver cursor, DataFusion stream) into a bounded async `AsyncIterator[pa.RecordBatch]`. Single source of truth for backpressure, cancellation propagation, deadline enforcement, and budget accounting. Centralized so bugs get fixed once.

### Layer 4 — Source executors (`nexcraft.executors`)
One module per source. Each implements `SourceExecutor`. Pass-through executors use ADBC where possible. Lakehouse executors use `datafusion-python` and the relevant format library. Executors are *thin*: connect, execute, wrap in `CancellableArrowStream`, return.

### Layer 5 — Worker public API (`nexcraft.client`, `nexcraft.router`)
Worker-internal `Router` does source resolution and executor dispatch within a worker process. `FedSQLClient` is a thin facade over the router with convenience methods (`execute`, `execute_to_table`, `describe`). Used by `nexcraft-jobs` recipes when they call into a worker.

### Layer 6 — Worker service (`nexcraft.worker`)
The worker's external surface. Internal Flight server accepting `nexcraft.WorkerExecute` actions from drivers. Capacity reporting to Redis. Heartbeat lifecycle. Graceful drain.

### Layer 7 — Public servers (`nexcraft.server.flight`, `nexcraft.server.http`)
Driver-side. Flight SQL and HTTP/REST endpoints exposed to clients. Both terminate on the driver, not on workers. Default deployment uses Flight SQL primary.

### Layer 8 — Driver service (`nexcraft.driver`)
Authentication, tenant resolution, cache integration, admission control, routing policy, worker registry, query dispatch. Specified in detail in [`10-driver-worker.md`](10-driver-worker.md). The control plane.

## Component interaction — request flow

A live query, end to end:

```
1. Client sends Flight SQL Execute(source_id, sql) to driver.

2. Driver auth middleware validates JWT → TenantIdentity.

3. Driver Router.handle_query():
     a. Catalog.get_source(source_id, tenant_id) → SourceDescriptor
        (raises SourceNotFoundError if tenant can't reach source)
     b. Build QueryContext with cache_mode, deadlines, budgets.
     c. If cache_mode != off:
          Cache.get(cache_key) → CachedHit | None
          On hit: stream from cache, return. Done.
     d. Admission.admit(ctx) → AdmissionDecision
        On reject: 503 / RESOURCE_EXHAUSTED with retry-after.
     e. RoutingPolicy.choose(workers, tenant, source) → Worker
     f. Driver dispatches WorkerExecute to chosen worker.

4. Worker receives WorkerExecute.
     a. Worker Router.execute(source_id, sql, ctx).
     b. ConnectionProvider.acquire(source_id, ctx) → ConnectionHandle
     c. Executor.execute(sql, ctx, conn) → CancellableArrowStream
     d. Stream batches back to driver.

5. Driver proxies the Arrow stream back to client.
   On success, populates cache (if cache_mode != off and result fits cap).

6. Driver releases admission slot, emits audit log + metrics.
```

Total path latency: driver overhead (typically 10-30 ms) + worker dispatch (<1 ms) + source-side execution (the dominant term).

## Where Path 1 (`nexcraft`) and Path 2 (`nexcraft-jobs`) meet

```
┌──────────────────────────────────────────────────────────┐
│                    nexcraft-jobs                         │
│  ┌────────────────────────────────────────────────────┐  │
│  │ Recipe                                             │  │
│  │   extract → stage → compute → persist              │  │
│  └────────────────────────────────────────────────────┘  │
│             │                                            │
│             │  uses FedSQLClient via driver for extract  │
└─────────────┼────────────────────────────────────────────┘
              ▼
┌──────────────────────────────────────────────────────────┐
│                  nexcraft (driver)                       │
└──────────────────────────────────────────────────────────┘
              │
              ▼
┌──────────────────────────────────────────────────────────┐
│                 nexcraft (workers)                       │
└──────────────────────────────────────────────────────────┘
```

`nexcraft-jobs` recipes call `nexcraft` for their extract phase via the driver — same Flight SQL endpoint clients use. Recipes get caching, quotas, audit for free. The federation service doesn't know whether the caller is an interactive agent or a Temporal worker. Same client, same driver, same workers, same `SourceExecutor`, same Arrow streams.

This is architecturally important: there is no separate "batch federation" path. The same federation primitive serves both, the difference is only in who's calling and what budgets they set.

## Why the driver/worker split

Three reasons specific to multi-tenancy (the design's first-class concern):

**Tenant fairness needs one coordinator.** Per-tenant concurrency caps, quota counters, weighted fair queuing — these require a single decision point. With stateless workers behind an LB alone, every worker would coordinate on every query via Redis. The driver collapses this into one round trip per query.

**Tenant audit must be unified.** Compliance audits ask "what did tenant T do across the system in time range X?" The driver sees every query for every tenant; the audit story is one log stream rather than aggregated across N workers.

**On-prem multi-tenant deployments often have one ingress.** Customers don't want their internal network exposing N worker endpoints. The driver is the one externally-reachable endpoint; workers run in a private network reachable only from drivers. Operationally simpler, security boundary cleaner.

The cost: the driver is a coordination point. Driver HA, scaling, and Redis dependency become real operational concerns. Detailed in [`10-driver-worker.md`](10-driver-worker.md).

## Why two execution paths inside the worker

The single most important shape decision in the executor layer is keeping pass-through and DataFusion-native executors visibly separate.

**Reasons:**

- *Different semantics.* Pass-through delegates planning to the source. DataFusion-native plans locally with pushdown into the scan. Forcing a unified abstraction over these papers over real differences and creates leaky abstractions.
- *Different dependency graphs.* Postgres-only deployments shouldn't pull in `iceberg-rust`'s avro/parquet transitive deps. Extras-based optional installs (`pip install 'nexcraft[postgres]'`) keep this clean.
- *Different failure modes.* Pass-through fails when the source fails (network, syntax, types). DataFusion-native fails when the file format is bad, the catalog is stale, or pushdown couldn't reduce a scan. Different errors, different remediation.
- *Different performance characteristics.* Pass-through latency is dominated by the source. DataFusion-native latency is dominated by metadata and scan. Different observability, different tuning.

The protocol unifies the *call shape*. The executors don't pretend to be the same thing.

## What's in scope per layer

| Layer | In scope | Out of scope |
|-------|----------|--------------|
| Core protocols | Stability, minimalism, zero deps | Convenience helpers |
| Pluggables | Reference impls, well-documented protocols | Production-grade catalogs/conn-mgrs |
| Streaming | Backpressure, cancellation, budgets, deadlines | Caching, materialization |
| Executors | Per-source connect/execute/stream | Cross-source joins, dialect translation |
| Worker public API | Worker Router dispatch, client facade | Query optimization |
| Worker service | Internal Flight, capacity, drain | Worker-side auth (delegated to driver) |
| Public servers | Flight SQL, HTTP — both thin | Auth backends, RBAC |
| Driver service | Auth, routing, cache, admission, audit | SQL parsing, query planning |

## Single-instance vs distributed deployment

Same code paths in both. The difference is the deployment topology.

**Single-instance dev** — driver, worker, and Redis (fakeredis) in one Python process via `nexcraft serve --mode=combined`. Useful for local development, CI tests, quickstarts.

**Multi-instance, single-region** — typical production. 2 driver replicas behind a load balancer, N workers per tier registered with Redis, Redis Sentinel for HA.

**Multi-tenant on-prem** — driver is the only externally reachable endpoint. Workers in a private subnet. Customer-managed Redis. Detailed in [`10-driver-worker.md`](10-driver-worker.md).

The architectural shape doesn't change with deployment topology. Operators scale horizontally by adding workers (and drivers, if driver CPU is the bottleneck).
