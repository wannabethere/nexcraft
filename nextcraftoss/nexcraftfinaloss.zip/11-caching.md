# 11 — Caching and Availability

The driver owns the cache. Workers never see it. This document specifies the cache layers, the modes callers opt into, the keying and invalidation model, the storage backends, and the availability properties that fall out of caching honestly.

## Position

Three principles, in priority order:

1. **Opt-in, default off.** A query that doesn't say `cache_mode != "off"` never touches the cache. Caching is a tool callers reach for deliberately, not a hidden behavior that surprises them.
2. **The cache is a tool for the live-query workload.** Pre-aggregations, materialized views, and scheduled rollups are jobs in `nexcraft-jobs`. The cache is the complement: short-TTL, query-shaped, populated on demand. Different shape, different lifecycle, different doc.
3. **Honest staleness.** Every response carries cache state metadata. Callers see "this is fresh," "this is N seconds stale," "this is a stale-on-source-failure response." Hidden caches are the bug class where users distrust the system; surfaced cache state is the property that lets them trust it.

## The four-layer model

Several distinct things people call "cache" should be kept separate. Conflating them is where caching designs go wrong.

```
┌──────────────────────────────────────────────────────────────────────┐
│ L0 — Result cache                                                    │
│      Key: source_id + normalized_sql + tenant_id + principal         │
│      Value: Arrow IPC of completed query results                     │
│      Owner: driver                                                   │
│      Backend: Redis (default), pluggable                             │
│      Hit path: skip dispatch entirely                                │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│ L1 — Plan / describe cache                                           │
│      Key: source_id + normalized_sql                                 │
│      Value: serialized pa.Schema                                     │
│      Owner: driver                                                   │
│      Backend: Redis (same backend as L0)                             │
│      Hit path: skip describe round trip; still dispatch for execute  │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│ L2 — Connection pool                                                 │
│      Specified in 02-protocols.md / 03-executors.md                  │
│      Owned by ConnectionProvider on each worker                      │
│      Operationally cache-shaped (warm connections), not a data cache │
└──────────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────────┐
│ L3 — Materialized recipe results                                     │
│      Specified in jobs/04-storage.md                                 │
│      Parquet on object storage; metadata in Postgres                 │
│      Push-populated by scheduled recipes; long TTL                   │
│      Different shape from query cache: explicit, scheduled, durable  │
└──────────────────────────────────────────────────────────────────────┘
```

L0 and L1 are this document's subject. L2 and L3 are referenced for completeness.

## L0 — Result cache

The lever that makes dashboards fast. Most of the design weight goes here.

### What's stored

The Arrow result of a completed query. Stored as Arrow IPC bytes — the same wire format the executor would have streamed. The hit path returns an Arrow stream identical to a live execution; the only externally visible differences are latency (faster) and the cache-state header (see "Honest staleness" below).

```python
@dataclass
class CachedResult:
    schema_ipc: bytes              # Arrow schema, separate for fast describe-from-cache
    batches_ipc: bytes             # Arrow IPC stream, all batches concatenated
    row_count: int
    byte_count: int

    # Identity (for safety checks on read)
    source_id: str
    tenant_id: str
    principal: str                 # source-side principal that produced these rows
    sql_hash: str

    # Lifecycle
    cached_at: datetime
    expires_at: datetime
    populated_by_query_id: str     # for audit
```

### Cache key

Four components, joined with a non-printable separator and SHA-256'd:

```python
def cache_key(ctx: QueryContext, sql: str, principal: str) -> bytes:
    normalized = normalize_sql(sql)        # sqlglot-based: whitespace, identifier case
    payload = b"\x00".join([
        ctx.source_id.encode(),
        normalized.encode(),
        ctx.tenant_id.encode(),
        principal.encode(),
    ])
    return hashlib.sha256(payload).digest()
```

The four components are non-negotiable:

- **`source_id`** — different sources never share cache, even on identical SQL. Two Postgres instances might both have a `users` table; their results are distinct.
- **`normalized_sql`** — semantic equality is hard; we don't try. sqlglot normalizes whitespace, comment removal, identifier case, and parameter ordering. Anything beyond that (e.g., `SELECT a, b` vs `SELECT b, a` returning rearranged columns) is treated as a distinct query and does not share a cache entry.
- **`tenant_id`** — the hard tenant-isolation rule from [`09-security.md`](09-security.md). Even when RLS would prove two tenants would see identical rows, treating their caches as distinct is the only safe default. RLS evolves; "we proved equivalence once" is the bug class to avoid.
- **`principal`** — under credential patterns where multiple roles can serve one tenant (Pattern A or C from the security doc), two queries from the same tenant could bind to different source-side principals. Cache hits must match on principal, not just tenant — otherwise RLS leaks across role boundaries within a tenant.

The cost of strict keying is occasionally missing cache hits where a more permissive policy would have hit. The benefit is that the cache cannot become a data leak. This trade-off is correct.

### SQL normalization

Performed once per query by the driver before key generation. Uses sqlglot's parser:

```python
def normalize_sql(sql: str) -> str:
    # Parse to AST and back, with normalization options:
    # - identifiers: lowercase unquoted, preserve quoted
    # - whitespace: collapse
    # - comments: strip
    # - keywords: uppercase
    parsed = sqlglot.parse_one(sql)
    return parsed.sql(normalize=True, comments=False, pretty=False)
```

**Normalization is best-effort.** sqlglot's coverage is excellent across Postgres, Snowflake, BigQuery, but exotic constructs occasionally round-trip imperfectly. When normalization fails (parse error, unsupported syntax), fall back to using the raw SQL as the key — the cache is less effective for that query, but correctness is preserved.

Configurable per source via the source descriptor:

```yaml
sources:
  prod_pg:
    kind: postgres
    cache:
      sql_normalization: sqlglot     # or "none" to disable; "none" means raw-sql keys
```

### Cache modes

Four modes, declared per query via `QueryContext.cache_mode`:

```python
class CacheMode(Enum):
    OFF = "off"                                # default; never touch cache
    FRESH = "fresh"                            # read-through with TTL
    STALE_OK = "stale_ok"                      # read-through; serve stale on source failure
    STALE_WHILE_REVALIDATE = "stale_while_revalidate"
                                               # serve stale immediately; revalidate async
```

#### `off` (default)

The driver does not consult the cache, does not populate the cache, does not emit cache metrics for this query. The query is dispatched normally. This is the default because surprising callers with cached results is worse than missing speedups.

#### `fresh`

```
1. Check cache.
2. If hit and not expired → return cached result, mark cache_state = "hit".
3. Otherwise → dispatch, stream to client, populate cache on success.
```

The simple read-through pattern. Use for dashboards with a defined refresh cadence ("data is at most 5 minutes old").

#### `stale_ok`

```
1. Check cache.
2. If hit and not expired → return cached result, mark "hit".
3. If hit but expired → dispatch; if dispatch succeeds, return live and update cache.
                       If dispatch FAILS (source down, timeout) → return stale result,
                       mark cache_state = "stale", emit warning metric.
4. If miss → dispatch normally; no fallback available.
```

The availability mode. When the source has a bad day, dashboards keep working off the last known result. The "stale" cache_state lets BI tools display a "data may be stale" indicator.

#### `stale_while_revalidate`

```
1. Check cache.
2. If hit and not expired → return cached result, mark "hit".
3. If hit but expired → return stale result IMMEDIATELY, mark "revalidating",
                       and asynchronously dispatch to refresh the cache for the next query.
4. If miss → dispatch normally; populate cache.
```

The dashboard sweet spot. User-visible latency stays constant; freshness is restored in the background. Best for high-traffic dashboards where any individual query waiting for a refresh would be visible to users.

The revalidation is fire-and-forget from the original caller's perspective. If revalidation fails, the cache entry is left as-is (still serving stale until next attempt). Failures are visible via metrics, not in the response.

### TTL

Per-query overrides take precedence; otherwise per-source defaults apply.

```python
@dataclass(frozen=True)
class QueryContext:
    cache_mode: CacheMode = CacheMode.OFF
    cache_ttl: timedelta | None = None   # overrides source default
```

```yaml
sources:
  prod_pg:
    cache:
      default_ttl: 300         # seconds
      max_ttl: 3600            # caller cannot exceed this
```

A caller can set `cache_ttl=timedelta(seconds=600)` and override the default. The driver clamps to `max_ttl` if exceeded — operators don't want callers caching for arbitrary durations.

### Per-result size cap

Caching a 50 GB result is harmful. The cache rejects puts above a per-result byte cap:

```yaml
cache:
  max_cacheable_result_bytes: 104857600    # 100 MB default
```

Above the cap, the query streams normally to the client; the cache simply isn't populated. This is graceful degradation, not failure. Documented behavior; emits a `nexcraft_cache_skipped_size_total` metric so operators see when this happens.

### Per-tenant byte budget

A noisy tenant can otherwise fill the cache, evicting everyone else. The cache enforces per-tenant byte budgets:

```yaml
cache:
  max_bytes_per_tenant: 1073741824         # 1 GB per tenant default
```

When a tenant is at budget, new puts are silently skipped. The query still runs; it just doesn't populate. Eviction within a tenant is LRU. Across tenants, tenants that exceed their budget don't grow at the expense of others.

When the global cache is full, eviction is global LRU. Per-tenant caps prevent runaway; global LRU handles ambient pressure.

### Streaming caveat

The executor streams `RecordBatch`es. Caching them means buffering. Three options were considered; the design takes option 1.

**Option 1 (chosen) — Cache only on success, after buffering.** Driver buffers Arrow IPC into memory as the worker streams. On stream completion, the driver writes the buffer to Redis atomically. On error mid-stream, the buffer is discarded; nothing is cached. Cost: result-sized memory in the driver during execution. Acceptable because of the per-result size cap.

**Option 2 (not chosen) — Stream-write to cache concurrently.** Write to cache as batches arrive; mark "complete" at end. Subsequent readers can stream from cache while it's still being written. More complex (cache reader needs to handle partial entries), smaller memory profile.

**Option 3 (not chosen) — Don't cache streaming results.** Only cache results below a threshold; large results bypass cache. Effectively what option 1 + size cap produces, but option 1 keeps the API uniform.

Option 1 is correct for v0.1. Option 2 is a possible future optimization if hit rates on big-result queries warrant it; the protocol doesn't change.

### Cache get path

```python
async def maybe_serve_from_cache(
    self, ctx: QueryContext, sql: str, principal: str,
) -> CachedHit | None:
    if ctx.cache_mode == CacheMode.OFF:
        return None

    key = cache_key(ctx, sql, principal)
    entry = await self._cache.get(key)
    if entry is None:
        return None

    now = datetime.now(timezone.utc)
    is_fresh = entry.expires_at > now
    age = now - entry.cached_at

    match ctx.cache_mode:
        case CacheMode.FRESH:
            return CachedHit(entry, "hit", age) if is_fresh else None
        case CacheMode.STALE_OK:
            # If fresh, hit. If stale, return entry but mark for fallback.
            return CachedHit(entry, "hit" if is_fresh else "stale_candidate", age)
        case CacheMode.STALE_WHILE_REVALIDATE:
            if is_fresh:
                return CachedHit(entry, "hit", age)
            # Stale: return entry immediately, kick off revalidation
            asyncio.create_task(self._revalidate(ctx, sql, principal))
            return CachedHit(entry, "revalidating", age)
```

Cache reads are sub-ms with Redis on a fast network. The driver's cache-check path is bounded by Redis round-trip time + key derivation.

### Cache put path

```python
async def populate_cache(
    self, ctx: QueryContext, sql: str, principal: str,
    schema: pa.Schema, batches: list[pa.RecordBatch],
) -> None:
    if ctx.cache_mode == CacheMode.OFF:
        return
    total_bytes = sum(b.nbytes for b in batches)
    if total_bytes > self._max_cacheable_bytes:
        self._metrics.cache_skipped_size.inc()
        return
    if not await self._tenant_budget_allows(ctx.tenant_id, total_bytes):
        self._metrics.cache_skipped_tenant_budget.inc()
        return

    sink = io.BytesIO()
    writer = pa.ipc.new_stream(sink, schema)
    for batch in batches:
        writer.write_batch(batch)
    writer.close()

    entry = CachedResult(
        schema_ipc=schema.serialize().to_pybytes(),
        batches_ipc=sink.getvalue(),
        row_count=sum(b.num_rows for b in batches),
        byte_count=total_bytes,
        source_id=ctx.source_id, tenant_id=ctx.tenant_id, principal=principal,
        sql_hash=hashlib.sha256(sql.encode()).hexdigest(),
        cached_at=datetime.now(timezone.utc),
        expires_at=datetime.now(timezone.utc) + (ctx.cache_ttl or self._default_ttl(ctx)),
        populated_by_query_id=ctx.query_id,
    )

    ttl = (ctx.cache_ttl or self._default_ttl(ctx)).total_seconds()
    await self._cache.put(cache_key(ctx, sql, principal), entry, ttl=ttl)
    await self._tenant_budget_consume(ctx.tenant_id, total_bytes)
```

Population happens after the stream completes successfully. Failed streams (errors, cancellation, deadline exceeded) do not populate. Partial results are never cached.

## L1 — Plan / describe cache

Smaller, simpler, almost free. Different lifecycle from L0.

`executor.describe(sql, ctx, conn)` returns a `pa.Schema`. It's deterministic given `(source_id, normalized_sql)` — tenant-independent because `describe` returns metadata, not data. Schemas are stable across executions; they change only when the source schema changes.

**Cache:**

- Key: `sha256(source_id + "\x00" + normalized_sql)`. No tenant. No principal.
- Value: serialized `pa.Schema` (small; tens to hundreds of bytes).
- TTL: hours. Default 1 hour; configurable per source. Source schema changes are rare and out-of-band.
- Hit path: skip the worker `describe()` round trip; still dispatch for execute.

This is the "dashboard tile load is 200 ms instead of 250 ms" optimization — describe round trips are 50-100 ms each on a remote source, and dashboards do many of them.

**Invalidation by schema mismatch:** when a query executes and the actual result schema doesn't match the cached describe schema, the L1 entry is invalidated and the new schema is cached. This catches schema drift automatically without needing explicit invalidation.

**Storage:** same Redis backend as L0. Different key prefix (`describe:` vs `result:`). Different TTL and eviction profiles, but the operational story is shared.

## Cache invalidation

The hardest part of any cache design. We deliberately constrain ourselves.

### TTL only — v0.1

Default and only mechanism. The cache says "5 minutes" and means it. Acceptable for the dashboard workload, where bounded staleness is tolerated. Honest in its limitations.

This is intentionally limited. Operators evaluating the cache understand "we get TTL-bounded staleness; if we need fresher, we lower the TTL or use `cache_mode=off`." No surprises.

### Tag-based purge — v0.2 candidate

Callers can attach tags to queries and later purge by tag:

```python
ctx = QueryContext(
    ...,
    cache_mode=CacheMode.FRESH,
    cache_tags=("table:orders", "tenant:42"),
)
# ...
await client.cache_purge(tags=["table:orders"])
```

The driver maintains tag → key indices in Redis. Purging by tag iterates the index and deletes keys.

Costs:

- Tag indices in Redis grow with cache size.
- Purges are O(tagged-keys), can be slow for popular tags.
- Callers must track when to purge — usually impractical except for small surfaces.

Worth shipping if there's pull from real users. Don't ship speculatively.

### CDC-driven invalidation — out of scope

Listening to source change streams (Debezium, Snowflake streams, BigQuery change data feeds) and invalidating by table reference. Powerful, complex, scope-creep risk.

Reasoning: this is its own product. Deferring indefinitely is the right call.

## Storage backends

The cache is pluggable via a small protocol:

```python
class ResultCache(Protocol):
    async def get(self, key: bytes) -> CachedResult | None: ...
    async def put(self, key: bytes, value: CachedResult, ttl_seconds: int) -> None: ...
    async def purge(self, key: bytes) -> None: ...
    async def purge_pattern(self, pattern: str) -> int: ...   # v0.2

    # Optional for tenant-budget enforcement
    async def tenant_bytes(self, tenant_id: str) -> int: ...
    async def evict_tenant_lru(self, tenant_id: str, bytes_needed: int) -> int: ...
```

### Reference implementations

**`InMemoryResultCache`**

- LRU with byte-budget cap.
- Per-process, lost on driver restart.
- For single-instance dev and small deployments where Redis is overkill.
- Implementation: `cachetools.LRUCache` with a bytes-based size estimator.

**`RedisResultCache`** (default)

- Redis 6+ with `maxmemory-policy: allkeys-lru`.
- Shared across driver replicas.
- Persistence (RDB or AOF) recommended for cache survival across Redis restarts.
- Implementation: `redis-py` async client; sets keys with `EX` for TTL.

**`LayeredResultCache(local=InMemory, remote=Redis)`**

- Two-tier: hot in local memory (microseconds), warm in Redis (single-digit ms).
- Local layer is small (e.g., 256 MB per driver); Redis layer is the source of truth.
- Reads check local, fall back to Redis, populate local on Redis hit.
- Writes write through to both.

Production deployments typically use the layered cache. Driver-local hits dominate at scale; Redis catches misses across drivers.

### S3 / object storage backend

A `S3ResultCache` is conceivable for archival caching of big results. Not in v0.1. Operators who need it can plug their own `ResultCache` impl.

## Honest staleness — response metadata

Every response carries cache state. The `FedSQLClient` exposes it; the Flight SQL and HTTP servers surface it on the wire.

```python
@dataclass
class ExecutionResult:
    stream: AsyncIterator[pa.RecordBatch]
    schema: pa.Schema
    cache_state: Literal["miss", "hit", "stale", "revalidating"]
    cached_at: datetime | None
    age: timedelta | None
    source_id: str
    query_id: str
```

For Flight SQL, this rides as gRPC metadata on the response:

```
nexcraft-cache-state: hit
nexcraft-cached-at: 2026-05-08T14:30:00Z
nexcraft-cache-age-seconds: 142
```

For HTTP:

```
X-Nexcraft-Cache-State: hit
X-Nexcraft-Cached-At: 2026-05-08T14:30:00Z
X-Nexcraft-Cache-Age-Seconds: 142
```

BI tools and dashboards use this to display "data is N minutes old" indicators. Surfaced cache state is what makes the cache trustworthy.

## Availability — what falls out of L0

Once L0 exists with a `stale_ok` mode, availability mostly works without additional infrastructure:

**Source down → cache serves stale.** A `stale_ok` query against a downed Postgres returns the last-known result, marked `cache_state: stale`. Dashboards keep loading. Operators see "cache served stale" rate spike, paging at threshold.

**Source slow → revalidate behind.** `stale_while_revalidate` cuts user-visible latency to constant time even when the source is having a bad day. The next request gets fresh; the user-facing one already returned.

**Source overload → cache absorbs pressure.** When the source rate-limits, retried queries may hit cache instead of piling onto the source. The cache is a natural pressure-relief valve.

**Driver crash → stateless recovery.** A driver mid-execute loses its in-flight queries; clients retry. Cached entries survive (Redis is independent). Fresh queries re-populate naturally.

What this *doesn't* solve:

- **First-time queries with source down.** No cache entry → no fallback. The query fails. Acceptable; the alternative is fabricating data.
- **Cache infrastructure availability becomes a dependency.** Redis going down means cache misses for everyone. Mitigation: layered cache with local-tier fallback keeps hot queries serving even if Redis is unavailable.
- **Long-tail queries.** Queries that aren't in cache (cold dashboard tiles, ad-hoc) fail like usual when the source is down.

Document this honestly: **"we have a cache that absorbs source outages; we don't have hot-standby cross-region failover."** Different shape, often sufficient for analytical workloads.

## Cache and `nexcraft-jobs` — the L0/L3 boundary

Recipes (`nexcraft-jobs`) and live queries (`nexcraft`) both produce cached-shape data. They're complementary, not redundant:

| | L0 (query cache) | L3 (recipe results) |
|---|---|---|
| Population | Pull (on cache miss) | Push (scheduled job) |
| Granularity | One query | One recipe = one or many tables |
| Staleness control | TTL + driver invalidation | Re-run schedule |
| Latency | Sub-second hit | Sub-second hit (Parquet read) |
| Scope | Live query workload | Pre-computed analytical workload |
| Storage | Redis | Object storage + Postgres metadata |

**The integration that matters:** dashboards can query L3 directly via a `nexcraft` source. A recipe result Parquet file *is* a queryable source — register `s3://bucket/jobs/.../primary.parquet` as a `parquet` source (or `iceberg` if recipes write Iceberg tables), and dashboards read it through the same `FedSQLClient`.

This is a powerful pattern. The heavy `WHERE region = ? GROUP BY product, month` aggregation runs once a day as a recipe, writes Parquet, and the dashboard reads pre-aggregated results in milliseconds. **Materialization beats caching when you can predict the query shape.**

Architectural rule of thumb:

- **Use L0 (cache)** for live federation queries with bounded but unpredictable parameters. "Show me revenue for region X" where X varies.
- **Use L3 (recipe materialization)** for predictable aggregations refreshed on schedule. "Daily revenue by region+product+month."

Most dashboards use both: pre-aggregated facts in L3, drill-downs against L0.

## Operator concerns

### Sizing Redis

Per-cache-entry overhead in Redis is small (~100 bytes plus the Arrow IPC bytes). Plan for:

- Cache size = expected concurrent unique queries × average result size.
- For 1000 active queries averaging 10 MB results = 10 GB Redis cache.
- Add 30% headroom for indices and per-tenant byte budgets.

Redis with `maxmemory-policy: allkeys-lru` evicts oldest cold entries when full. This is the desired behavior — cache pressure should produce evictions, not errors.

### Choosing TTLs

The cache is most valuable when TTL > query repetition interval. Concretely:

- Dashboard tile refreshes every 30 seconds → TTL of 60 seconds catches most repeats.
- Per-user dashboard with 100 users viewing the same data → TTL of 5 minutes serves 99% from cache.
- Very high-traffic embedded analytics → use `stale_while_revalidate` with TTL of 30-60 seconds; user-visible latency is always sub-second.

Start permissive (longer TTLs), tighten if staleness complaints arrive. It's easier to relax than tighten without breaking expectations.

### Monitoring

Required metrics (see [`06-observability.md`](06-observability.md) for schema):

- `nexcraft_cache_requests_total{mode, outcome}` — `outcome ∈ {hit, miss, stale, revalidating, skipped}`
- `nexcraft_cache_bytes_current{}` — gauge of current cache size
- `nexcraft_cache_bytes_per_tenant{tenant_id}` — top-K only to avoid cardinality explosion
- `nexcraft_cache_evictions_total{reason}` — `reason ∈ {ttl, lru, tenant_budget, manual_purge}`
- `nexcraft_cache_skipped_size_total{}` — queries above per-result cap
- `nexcraft_cache_skipped_tenant_budget_total{tenant_id}` — top-K
- `nexcraft_cache_revalidate_failures_total{source_id}` — `stale_while_revalidate` revalidations that failed

The dashboard for cache health: hit rate by mode, eviction rate, tenant byte distribution, revalidation success rate.

### Cache invalidation in operations

For v0.1, the only invalidation tools are:

- **Wait for TTL.** The default mechanism.
- **Manual purge** via admin API: `POST /admin/cache/purge` with key pattern. Operators reach for this when an upstream change requires forcing fresh data.

Document both. Make the admin API authenticated and audited — purges are operational events that matter for traceability.

## What's deliberately out of scope

To keep the cache layer narrow:

- **No semantic caching.** Cache hits on "equivalent" queries via SQL rewriting. Different normalized SQL → different keys. sqlglot normalization is the only normalization.
- **No partial result caching.** Either the whole result is cached or none of it. Subquery-level caching is what warehouses do; not our job.
- **No cross-tenant deduplication.** Even if proven equivalent. Tenant boundary is a hard line.
- **No write-through caching.** Read-only.
- **No proactive cache warming.** That's what recipes are for. The driver doesn't pre-fetch.
- **No cache as primary storage.** It's a cache. Source is source of truth.
- **No compression beyond Arrow IPC's built-in.** Arrow's LZ4 frame compression is good enough; adding another layer is unjustified complexity for the data shape.

## Operational checklist

Before relying on the cache in production:

- [ ] Redis HA configured (Sentinel or Cluster) with persistence.
- [ ] `maxmemory` and `maxmemory-policy: allkeys-lru` set.
- [ ] Per-source `default_ttl` and `max_ttl` configured.
- [ ] `max_cacheable_result_bytes` set to a value that fits typical results.
- [ ] `max_bytes_per_tenant` set; verified with one tenant's expected workload.
- [ ] Cache state metadata exposed in client SDKs / BI tool integrations.
- [ ] Metrics dashboards include hit rate by mode, eviction rate, tenant distribution.
- [ ] Admin purge API authenticated and audited.
- [ ] Documentation for client developers explains cache modes and when to use which.
- [ ] Layered cache enabled if multi-driver deployment (local + Redis).
- [ ] Cancellation tested end-to-end with `stale_while_revalidate`: cancelling the original request does not cancel the background revalidation.

This list goes in the `how-to/operate-cache.md` doc on the user-facing site.
