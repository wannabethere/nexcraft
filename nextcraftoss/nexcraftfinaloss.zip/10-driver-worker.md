# 10 — Driver / Worker Architecture

The deployment shape for `nexcraft`. A driver coordinates; workers execute. Multi-tenancy is first-class: tenants are isolated, fairly sharing capacity, and observable per-tenant from a single coordination point.

This document specifies the driver and worker roles, the control protocol between them, the multi-tenancy model, and the deployment footprint from single-instance dev through multi-instance on-prem.

## Position

Three principles, in priority order:

1. **The driver is a control plane.** It owns cache, routing decisions, tenant quotas, admission control, and worker registry. It does not parse SQL, rewrite queries, or orchestrate cross-source work.
2. **The driver is in the data path only when required.** For cache hits, the driver returns the cached Arrow stream directly. For cache misses, the driver proxies the worker's stream back to the client. A future evolution to ticket-based direct streaming (worker → client) is non-breaking — the driver-side protocol allows it.
3. **Single instance is a deployment concern, not an architecture concern.** "One driver, one worker, same host" runs the same code as "two driver replicas, twenty workers, three regions." The shape doesn't change; the count does.

## Topology

```
┌────────────────────────────────────────────────────────────────────────┐
│                              Clients                                   │
│             (agents, BI tools, apps, nexcraft-jobs workers)            │
└────────────────────────────┬───────────────────────────────────────────┘
                             │ Flight SQL / HTTP
                             ▼
┌────────────────────────────────────────────────────────────────────────┐
│                            Driver(s)                                   │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ Auth → Tenant Resolution → Catalog → Cache Check → Admission →   │  │
│  │   Worker Selection → Dispatch → Stream Proxy / Cache Population  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│      ▲                       ▲                       ▲                 │
│      │                       │                       │                 │
└──────┼───────────────────────┼───────────────────────┼─────────────────┘
       │                       │                       │
       ▼                       ▼                       ▼
   ┌───────┐               ┌───────┐               ┌───────┐
   │ Redis │               │Catalog│               │Workers│
   │       │               │Backend│               │ pool  │
   │ cache │               │       │               │       │
   │ regis-│               │  YAML │               │ N×    │
   │ try   │               │   DB  │               │ stat- │
   │ quotas│               │       │               │ less  │
   └───────┘               └───────┘               └───────┘
                                                        │
                                                        ▼
                                                  ┌────────┐
                                                  │Sources │
                                                  │ PG/SF/ │
                                                  │ Iceberg│
                                                  └────────┘
```

**Driver responsibilities** (control plane):

- Terminate client connections (Flight SQL, HTTP).
- Authenticate, resolve tenant identity from auth context.
- Resolve `source_id` to a `SourceDescriptor` via the catalog.
- Check per-tenant authorization on the source (delegates to `Catalog.get_source(source_id, tenant_id)`).
- Check the cache (Redis): hit → serve directly, miss → continue.
- Apply admission control: per-tenant quotas, per-worker capacity, global limits.
- Select a worker for execution (routing logic — pluggable).
- Dispatch the query to the chosen worker over the internal Flight protocol.
- Proxy the worker's Arrow stream back to the client; populate cache on success.
- Emit per-query audit log and metrics, tagged with tenant.

**Worker responsibilities** (data plane):

- Accept dispatched queries from drivers via internal Flight endpoint.
- Hold connection pools per source.
- Resolve source-side principal via the `ConnectionProvider` (using tenant from dispatch).
- Execute the query through the appropriate `SourceExecutor`.
- Stream Arrow `RecordBatch`es back to the driver.
- Emit OTel spans for executor, source query, and stream lifecycle.
- Report capacity (active queries, headroom) to the driver registry.

**Redis responsibilities** (shared state):

- Result cache (L0).
- Worker registry: heartbeats, capacity, tier, health.
- Per-tenant quota counters.
- Schema cache (L1, plan/describe results).
- Future: query queue.

**Workers know about**: their assigned sources, their connection pools, their executors. They do **not** know about tenants except as an opaque ID dispatched with each query. They do not know about caching. They do not know about other workers.

## Why driver/worker

Three reasons specific to multi-tenancy:

**Tenant fairness needs one coordinator.** Per-tenant concurrency caps, quota counters, weighted fair queuing — these require a single decision point. With stateless workers behind an LB, each worker would have to coordinate with every other worker via Redis on every query. The driver collapses this into one round trip: ask Redis, decide, dispatch.

**Tenant audit must be unified.** Compliance audits ask "what did tenant T do across the system in time range X?" In a stateless-worker model, audit logs are scattered across N workers and need aggregation. The driver sees every query for every tenant; the audit story is one log stream.

**On-prem multi-tenant deployments often have one ingress.** Customers don't want their internal network exposing N worker endpoints. The driver is the one externally-reachable endpoint; workers run in a private network reachable only from drivers. Operationally simpler, security boundary cleaner.

The cost: the driver is a coordination point, with the consequences that brings. See "Operational Concerns" below.

## Lightweight driver — what it does and doesn't do

To keep the driver from becoming the system's bottleneck or a complexity sink:

**The driver does:**

- Per-query routing decisions (~10ms budget, mostly Redis lookups).
- Cache get/put (cache hits are sub-ms; cache misses add a Redis round trip).
- Stream proxying (Arrow IPC is byte-level efficient — driver is a relay, not a transformer).
- Tenant quota accounting (Redis INCR/DECR, atomic).
- Audit emission (async, non-blocking).
- Worker health monitoring (Redis-backed registry with TTL'd heartbeats).

**The driver doesn't:**

- Parse SQL. The dialect SQL is opaque to the driver.
- Rewrite queries. The dialect is the caller's contract with the source.
- Coordinate cross-source queries. Single source per query, by design.
- Plan execution. The worker dispatches to one `SourceExecutor`; nothing to plan.
- Hold connections to sources. Workers do that.
- Run analytical compute. `nexcraft-jobs` does that.
- Validate result data. Arrow IPC passes through opaquely.

If a feature would require parsing SQL, rewriting it, or doing data-shaped work, it doesn't go in the driver.

## Multi-tenancy model

The first-class concern. Specified in detail because it shapes everything else.

### Tenant identity

`tenant_id` is asserted by the auth layer (validated JWT, mTLS peer cert, or — single-instance dev — config). The driver receives it as a trusted attribute on the request context. `nexcraft` does not validate auth tokens itself; it consumes the asserted identity.

```python
@dataclass
class TenantIdentity:
    tenant_id: str                  # required, opaque, non-empty
    tier: str = "default"           # "bronze" | "silver" | "gold" | custom
    subject: str | None = None      # original auth subject (for audit)
    claims: dict = field(default_factory=dict)  # auth-layer claims, opaque
```

The auth integration produces `TenantIdentity`. The driver routes based on it.

### Tenant isolation

Three isolation boundaries, layered:

**1. Source visibility.** `Catalog.get_source(source_id, tenant_id)` is the gate. Tenants asking about sources they can't see get `SourceNotFoundError` — the same error as nonexistent. No information leak.

**2. Connection principal.** The `ConnectionProvider` resolves the source-side principal from `(source_id, tenant_id)` per the patterns in [`09-security.md`](09-security.md). Tenant T's queries connect to the source as a principal that source-side RLS scopes to T.

**3. Cache namespace.** Cache keys include `tenant_id`. No cross-tenant cache sharing, even when results would be identical under RLS. Documented as a hard rule.

### Per-tenant quotas

Tracked in Redis, enforced in the driver. Three classes:

```python
@dataclass
class TenantQuota:
    # Concurrency
    max_concurrent_queries: int = 10
    max_concurrent_per_source: dict[str, int] = field(default_factory=dict)

    # Throughput
    max_qps: int | None = None              # token bucket
    max_bytes_per_minute: int | None = None # observed result bytes

    # Resource
    max_query_duration: timedelta = timedelta(minutes=10)
    max_result_rows: int | None = None
    max_result_bytes: int | None = None

    # Cache
    max_cache_bytes: int | None = None      # bytes this tenant may occupy
```

Quotas live in Redis under `quota:{tenant_id}` and are loaded by the driver on first request, refreshed on TTL. They derive from a `TenantQuotaProvider` — pluggable, with reference impls for static YAML and database-backed configurations.

Quota enforcement points:

- **Concurrency:** `INCR quota:{tenant_id}:concurrent` before dispatch; `DECR` on completion. Reject if over.
- **QPS:** token-bucket in Redis. Reject if exhausted.
- **Bytes/minute:** observed in stream proxy; reject *new* queries when exhausted (in-flight queries complete).
- **Result rows/bytes:** propagated to `QueryContext.max_rows`/`max_bytes`; the streaming primitive enforces.
- **Duration:** propagated to `QueryContext.deadline`.
- **Cache bytes:** enforced on cache `put`; over-quota tenants don't populate cache (their queries still run, just don't cache).

### Tier-based routing

Tenants have a tier (`bronze`/`silver`/`gold` or custom). Workers belong to tier pools. The driver routes based on tenant tier:

```python
def select_worker(self, tenant: TenantIdentity, source_id: str) -> Worker:
    tier_pool = self._registry.workers_for_tier(tenant.tier)
    candidates = [w for w in tier_pool if w.can_serve(source_id)]
    return self._routing_policy.choose(candidates, tenant, source_id)
```

A `Gold` tenant's queries land on `Gold` workers (high memory, more concurrent slots, possibly tenant-pinned). A `Bronze` tenant lands on `Bronze` workers (shared, oversubscribed). The routing policy is pluggable; the default is documented.

### Tenant affinity

Optional, opt-in per tenant: stick a tenant's queries to the same worker when possible, to maximize connection pool reuse and per-worker cache locality (if local-tier cache is enabled).

```python
class TenantAffinityPolicy(RoutingPolicy):
    def choose(self, candidates, tenant, source_id):
        preferred = self._registry.get_affinity(tenant.tenant_id)
        if preferred and preferred in candidates and preferred.has_capacity():
            return preferred
        choice = self._fallback.choose(candidates, tenant, source_id)
        self._registry.set_affinity(tenant.tenant_id, choice, ttl=300)
        return choice
```

Affinity is best-effort; when the preferred worker is full or down, fall back to any available. Affinity is invisible to the executor and worker — they don't know they were chosen for affinity reasons.

### Tenant audit

Every query produces an audit record (specified in [`09-security.md`](09-security.md)). The driver writes them; tenant ID is a required field. The audit sink is a separate concern from observability metrics — different retention, different access controls.

A "tenant activity" view is trivially derivable: filter the audit stream by `tenant_id`. No aggregation across workers needed.

## Driver internals

### Request flow

```python
async def handle_query(self, request: ExecuteRequest) -> AsyncIterator[pa.RecordBatch]:
    # 1. Auth → tenant identity (already done by auth middleware)
    tenant: TenantIdentity = self._auth.tenant_from_request(request)

    # 2. Resolve source (per-tenant authz happens here)
    descriptor = await self._catalog.get_source(request.source_id, tenant.tenant_id)

    # 3. Build query context
    ctx = self._build_query_context(request, tenant, descriptor)

    # 4. Cache check
    if ctx.cache_mode != "off":
        cached = await self._cache.get(self._cache_key(ctx, request.sql))
        if cached and self._is_fresh(cached, ctx):
            await self._audit.log_cache_hit(ctx)
            return self._stream_from_cache(cached)

    # 5. Admission
    decision = await self._admission.admit(ctx)
    if not decision.admitted:
        await self._audit.log_rejection(ctx, decision.reason)
        raise ResourceExhaustedError(reason=decision.reason,
                                     retry_after_ms=decision.retry_after_ms)

    try:
        # 6. Worker selection
        worker = await self._router.select_worker(tenant, descriptor)

        # 7. Dispatch + stream proxy
        worker_stream = await self._dispatch_to_worker(worker, request, ctx)
        return self._proxy_with_cache_population(worker_stream, ctx, request.sql)

    finally:
        await self._admission.release(ctx)
```

Each step is synchronous and bounded in latency. Total driver overhead per query (excluding worker time): typically 10-30ms with Redis on the same network.

### Cache integration

The cache is owned by the driver. Workers don't see it.

```python
class DriverCache:
    """Result cache + plan cache + worker affinity, backed by Redis."""

    async def get(self, key: bytes) -> CachedResult | None: ...
    async def put(self, key: bytes, value: CachedResult, ttl: timedelta,
                   tenant_id: str) -> None:
        # Per-tenant byte-budget enforcement
        if not await self._tenant_budget_allows(tenant_id, len(value.batches_ipc)):
            return  # silent skip; cache is best-effort
        await self._redis.set(key, value.serialize(), ex=int(ttl.total_seconds()))
        await self._tenant_budget_consume(tenant_id, len(value.batches_ipc))
```

Cache modes (`off` / `fresh` / `stale_ok` / `stale_while_revalidate`) are specified per-query via `QueryContext.cache_mode`. The driver applies them.

### Stream proxying

For cache misses, the driver proxies the worker's Arrow stream to the client, optionally tee-ing to the cache:

```python
async def _proxy_with_cache_population(
    self, worker_stream: AsyncIterator[pa.RecordBatch],
    ctx: QueryContext, sql: str,
) -> AsyncIterator[pa.RecordBatch]:
    sink = io.BytesIO() if ctx.cache_mode != "off" else None
    writer = None
    rows = 0; bytes_ = 0

    async for batch in worker_stream:
        if sink is not None and bytes_ < self._max_cacheable_bytes:
            if writer is None:
                writer = pa.ipc.new_stream(sink, batch.schema)
            writer.write_batch(batch)
        rows += batch.num_rows
        bytes_ += batch.nbytes
        yield batch  # to client

    # On success, populate cache
    if sink is not None and writer is not None and bytes_ <= self._max_cacheable_bytes:
        writer.close()
        await self._cache.put(self._cache_key(ctx, sql),
                              CachedResult(batches_ipc=sink.getvalue(), ...),
                              ttl=ctx.cache_ttl or self._default_ttl(ctx),
                              tenant_id=ctx.tenant_id)
```

Two design notes:

- **Cache only on success.** Errors don't populate. A failed stream leaves the cache untouched.
- **Bypass cache for big results.** If `bytes_` exceeds `max_cacheable_bytes` (default 100 MB), the cache is not populated. Streaming continues normally. Documented as graceful degradation.

### Worker registry

Workers register with the driver via Redis on startup and heartbeat periodically. The driver reads the registry on each query for routing decisions.

```python
@dataclass
class WorkerRegistration:
    worker_id: str                    # ULID
    address: str                      # internal Flight address (e.g. flight://10.0.1.4:50051)
    tier: str
    sources_supported: list[str]      # source_ids this worker can serve
    executor_kinds: list[str]         # kinds installed (postgres, snowflake, ...)
    started_at: datetime
    last_heartbeat: datetime
    capacity: WorkerCapacity

@dataclass
class WorkerCapacity:
    max_concurrent: int
    current_concurrent: int
    available_slots: int              # max - current
    cpu_load: float | None = None     # last reported, 0..1
    memory_used_bytes: int | None = None
```

Stored in Redis as `worker:{worker_id}` with TTL = `heartbeat_interval × 3`. Stale entries auto-expire.

The driver maintains an in-memory mirror refreshed every 1-2 seconds. Routing decisions read from the mirror — no Redis round trip per query for worker selection.

### Routing policies

Pluggable. `RoutingPolicy` protocol:

```python
class RoutingPolicy(Protocol):
    def choose(
        self,
        candidates: list[WorkerRegistration],
        tenant: TenantIdentity,
        source_id: str,
    ) -> WorkerRegistration:
        """Returns the worker to dispatch to. Raises NoWorkerAvailableError
        if no candidate has capacity."""
```

Reference policies shipped:

- **`LeastLoadedPolicy`** — picks the worker with most `available_slots`. Default.
- **`RoundRobinPolicy`** — simple round-robin.
- **`TenantAffinityPolicy`** — sticky-by-tenant with fallback to least-loaded.
- **`SourceAffinityPolicy`** — prefer workers that already have a warm connection to the source. Cuts cold-connection latency on first query of a source.

Custom policies plug in via configuration:

```yaml
driver:
  routing:
    policy: custom
    module: mycompany.routing.PriorityQueueRoutingPolicy
    config:
      gold_overflow_to_silver: true
      bronze_max_queue_depth: 50
```

The configuration model is intentionally simple: dotted-path module reference plus a config dict. Operators distribute policies as Python packages installed alongside `nexcraft`.

## Worker internals

Workers are intentionally minimal.

### Worker startup

```python
class Worker:
    def __init__(self, config: WorkerConfig):
        self._tier = config.tier
        self._executors = self._load_executors(config.enabled_executors)
        self._provider = config.connection_provider
        self._catalog = config.catalog
        self._registry = WorkerRegistryClient(config.redis)
        self._flight = WorkerFlightServer(self)

    async def start(self):
        await self._provider.start()
        await self._flight.start(bind=self._config.bind)
        await self._registry.register(self._registration())
        asyncio.create_task(self._heartbeat_loop())
```

A worker does not need to know about tenants, the cache, the auth layer, or other workers. It needs a connection provider, a catalog (for source descriptors), executors, and a way to talk to Redis (for heartbeats).

### Internal Flight protocol

The driver-to-worker protocol is Flight SQL with `nexcraft.WorkerExecute` action:

```proto
syntax = "proto3";
package nexcraft.flight.worker.v1;

message WorkerExecuteRequest {
  string source_id        = 1;
  string sql              = 2;
  string query_id         = 3;
  string tenant_id        = 4;     // opaque to the worker
  string trace_id         = 5;
  int64  deadline_ms      = 6;
  optional int64 max_rows  = 7;
  optional int64 max_bytes = 8;
  int32  target_partitions = 9;
  int32  batch_size_hint   = 10;
  // Tenant-specific principal hint, resolved by ConnectionProvider
  map<string, string> connection_hints = 11;
}
```

Workers expose this on an internal Flight endpoint. The driver dispatches by sending `WorkerExecute` then `do_get(ticket)` to stream results. Workers implement `do_action` for executes and `do_get` for streaming.

The internal protocol is *not* the public API. Public API is Flight SQL `nexcraft.Execute` (per [`05-servers.md`](05-servers.md)); internal API is `nexcraft.WorkerExecute`. They look similar but evolve independently — the worker protocol can change with worker versions; the public API has stronger stability guarantees.

### Worker authorization

Workers trust the driver. The driver authenticates clients; workers authenticate drivers. Two patterns:

- **mTLS internal.** Drivers and workers exchange certificates issued by an internal CA. Worker rejects connections without a valid driver cert. Default for production.
- **Shared secret.** Drivers sign internal requests with an HMAC; workers verify. Lighter than mTLS for single-instance and small deployments.

Workers do not validate `tenant_id` independently — they trust whatever the driver dispatched. The driver is the authorization boundary. This is critical: a compromised worker can't escalate privilege beyond what its connection provider allows, but a compromised driver can. Drivers therefore require stricter operational controls.

## Multi-tenancy in single-instance and on-prem

### Single-instance dev

Driver and worker run in the same Python process. Redis can be in-process (fakeredis) or a small dev container. All quotas configurable; `tenant_id="default"` works for single-tenant dev.

```bash
# All-in-one for local development:
nexcraft serve --mode=combined --config=dev.yaml
```

The combined mode is the same code paths — driver + worker + Redis-fake — just colocated. Useful for tests.

### Multi-instance, single-region

The most common production shape:

- 2 driver replicas behind an LB (active/active, both serve traffic).
- N workers per tier, registered with Redis.
- Redis Sentinel or single-node Redis (depending on availability requirements).

Driver replicas are stateless w.r.t. driver-local memory — all coordination state lives in Redis. Either driver can serve any request.

### On-prem multi-tenant

The motivating case. Typically:

- Customer runs a dedicated `nexcraft` deployment per environment.
- Each environment serves multiple internal teams as tenants.
- Drivers are the only externally-reachable endpoints.
- Workers run in a private subnet, reachable only from drivers.
- Redis is on-prem; some customers prefer a dedicated Redis instance per environment.
- Sources are inside the customer network (their Postgres, their warehouse).

The driver is the network boundary, the security boundary, and the multi-tenancy boundary. This is precisely why a stateless-worker-behind-LB model doesn't fit: the LB would be the network boundary, but it's not the multi-tenancy boundary, and operators end up adding sidecars to fix it. The driver is the proper place.

## Operational concerns

### Driver high availability

Two drivers active/active behind an LB. State in Redis. Either driver loses → LB withdraws, the other serves alone. No failover; no leader election.

If both drivers fail simultaneously: the system is down. This is acceptable when:
- Drivers are a known-cheap-to-restart workload (lightweight, fast startup).
- Redis itself is HA.
- Workers continue holding their connection pools and resume quickly when a driver returns.

For higher availability, add a third driver. Diminishing returns past three.

### Driver as throughput bottleneck

The driver does real work per query (cache lookup, routing, audit). Sized poorly, it bottlenecks before workers do. Guidance:

- **Per-query overhead:** ~10-30ms of CPU on the driver, dominated by Redis round trips.
- **Sustainable QPS per driver core:** ~100-300 depending on cache hit rate.
- **Stream proxying CPU:** dominated by network I/O, not CPU; one driver core can proxy ~1 GB/s of Arrow IPC.
- **Memory:** worker registry mirror (~1KB per worker), in-flight query metadata (~10KB per query). 10 GB is plenty for thousands of workers and tens of thousands of in-flight queries.

If driver CPU is the bottleneck, the answer is more driver replicas, not bigger ones (Python GIL).

### Redis dependency

Redis is the driver's brain. Treat it accordingly:

- Use Redis Sentinel or Cluster in production.
- Configure persistence (RDB snapshots at minimum) so cache and registry survive restarts.
- Monitor latency — driver tail latency is bounded below by Redis round-trip time.
- Set conservative `maxmemory` policies (LRU eviction). Cache evictions are fine; quota counter eviction is bad.

For single-instance dev, a single Redis container is fine. For on-prem, document the HA Redis setup as part of the deployment guide.

### Worker hot-restart

Workers should be hot-replaceable: bring up a new worker, register, drain the old one, deregister. The driver routes around drained workers automatically (capacity reports zero available slots). Drain takes as long as the longest in-flight query — bounded by `QueryContext.deadline`.

Workers that crash without draining are detected by heartbeat expiry (default 30s). In-flight queries on a crashed worker error out; clients retry against another worker.

### Scaling the worker pool

Workers register on startup, deregister on graceful shutdown. The driver picks them up automatically. No driver restart needed.

Autoscaling triggers:

- **Up:** sustained `available_slots` < threshold (e.g., < 20% across the pool for 1 minute).
- **Down:** sustained `available_slots` > threshold (e.g., > 80% across the pool for 5 minutes), with grace period to avoid flapping.

Implemented externally (Kubernetes HPA, Nomad autoscaler, etc.) using the metrics in [`06-observability.md`](06-observability.md). `nexcraft` itself doesn't autoscale; it exposes the signals.

## What stays the same

The protocol surface from [`02-protocols.md`](02-protocols.md) is preserved:

- `SourceExecutor`, `Catalog`, `ConnectionProvider`, `QueryContext` — unchanged. These are worker-side contracts.
- `nexcraft.errors` — unchanged. Workers raise; drivers translate where needed (`ResourceExhaustedError` is new, driver-side only).
- `CancellableArrowStream` — unchanged. Workers use it. Drivers use a wrapping primitive for stream proxying.

The Public API in [`05-servers.md`](05-servers.md) is preserved with one addition:

- The HTTP/Flight servers documented there are now driver-side. Their semantics are unchanged from the client's perspective.
- A new internal-only Worker Flight protocol (`nexcraft.WorkerExecute`) lives alongside, not exposed to clients.

The conformance suite from [`07-testing.md`](07-testing.md) tests the worker — `SourceExecutor` implementations. A new driver conformance suite tests the driver: routing, cache, admission, multi-tenancy boundaries.

## What changes from earlier docs

A small list of concrete revisions to existing documents:

**`docs/01-architecture.md`** — top-level diagram and component descriptions need to show driver/worker split. The "two execution paths" section is preserved (it describes worker-internal behavior).

**`docs/05-servers.md`** — clarify that the Flight SQL and HTTP servers documented are driver-side. Add a brief section on worker-internal Flight.

**`docs/06-observability.md`** — split metrics into driver-emitted and worker-emitted. Driver emits routing-related metrics (cache hit rate, admission rejections, routing decisions); worker emits execution metrics (per-source latency, pushdown effectiveness).

**`docs/08-repo-layout.md`** — `nexcraft.driver` and `nexcraft.worker` modules. The `nexcraft.server` module becomes shared transport library used by both.

**`docs/09-security.md`** — add the driver as the trust boundary; clarify that workers trust drivers.

These are small revisions. The architectural ideas are preserved; the deployment model is sharpened.

## Future evolution paths preserved

Decisions made now that don't paint us into corners:

**Ticket-based direct streaming (Option 3 from earlier discussion).** The internal Flight protocol uses tickets. Today, the driver consumes the ticket and proxies. Tomorrow, the driver could return the ticket to the client, who follows it to the worker directly. The wire protocol doesn't change; the network topology does. This evolution is non-breaking.

**Query queuing.** When a tenant exceeds concurrency quota, instead of immediate rejection, the driver could queue the request in Redis with a TTL. A queued query gets a later admission attempt when capacity frees up. The admission control surface (`AdmissionController.admit() → AdmissionDecision`) already accommodates this — `AdmissionDecision.queued` is a future field.

**Cross-region driver-to-driver federation.** Drivers in different regions could route requests across regions (e.g., a tenant's data is in Region A; a query from Region B is forwarded to a Region A driver). The driver-to-worker dispatch protocol can be reused for driver-to-driver. Out of scope for v0.1; not blocked.

**Workflow integration with `nexcraft-jobs`.** Today `nexcraft-jobs` recipes call the driver as a Flight SQL client. They get caching, quotas, audit for free. No special integration needed.

## Operational checklist

Before going to production:

- [ ] Two driver replicas behind an LB, health-checked, both active.
- [ ] Redis HA configured (Sentinel or Cluster), persistence enabled.
- [ ] Worker pool sized per tier, registered with Redis, heartbeating.
- [ ] mTLS or shared secret configured for driver-worker communication.
- [ ] Per-tenant quotas configured via `TenantQuotaProvider`.
- [ ] `Catalog` enforces tenant visibility on `get_source`.
- [ ] `ConnectionProvider` resolves principals per tenant per [`09-security.md`](09-security.md).
- [ ] Audit sink separate from observability sink, with appropriate retention.
- [ ] Routing policy chosen and configured.
- [ ] Cache modes documented for client developers; default `off` confirmed.
- [ ] Cancellation tested end-to-end: client cancel → driver cancel → worker cancel → source cancel.
- [ ] Driver and worker can be hot-restarted independently.
- [ ] Single-instance dev mode (`--mode=combined`) verified for local development workflows.

This list goes in the `how-to/deploy-multi-tenant.md` doc on the user-facing site.
